
My roles

-Implemented Storage management systems( Add and manage storage vehicles
                                           - Add and manage charging stations
                                           - Assign items to storage vehicles
                                           - Track battery percentage for each vehicle
                                           - Vehicle–Charging station )


-Charging station and StorageItem classes

-Log Manager class(- Log every system action
                      - Create daily log files for:
                           • Each storage vehicle
                           • Each charging station
                           • Entire system operations
                      - Allow opening logs by equipment name or date)

Both:
Data Exchange Simulation (I/O Streams)
Main class
