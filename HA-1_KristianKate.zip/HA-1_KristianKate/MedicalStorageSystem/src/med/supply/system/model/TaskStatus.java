
package med.supply.system.model;

public enum TaskStatus {
    PENDING, IN_PROGRESS, DONE
}
